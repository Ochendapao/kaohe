//
//  YouWenTableViewController.m
//  CQUPT_CDP
//
//  Created by 陈大炮 on 2018/5/25.
//  Copyright © 2018年 陈大炮. All rights reserved.
//

#import "YouWenTableViewController.h"

@interface YouWenTableViewController ()
<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UITableView *allTable;


@end

@implementation YouWenTableViewController

-(UITableView *)allTable
{
    _allTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 105, 345, 521)style:UITableViewStylePlain];
    _allTable.delegate = self;
    _allTable.dataSource = self;
    
    return _allTable;
    
}












- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
