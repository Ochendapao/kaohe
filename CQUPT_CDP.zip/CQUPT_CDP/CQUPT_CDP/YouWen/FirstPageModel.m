//
//  FirstPageModel.m
//  CQUPT_CDP
//
//  Created by 陈大炮 on 2018/5/27.
//  Copyright © 2018年 陈大炮. All rights reserved.
//

#import "FirstPageModel.h"

@implementation FirstPageModel
-(instancetype)initWithDict:(NSDictionary *)dic{
    self = [self init];
    if (self) {
        self.title = dic[@"title"];
        self.timeLine = dic[@"created_at"];
        self.tagLabel = dic[@"tags"];
        self.reward  = dic[@"reward"];
        self.textViewContent =dic[@"description"];
    }
    return self;
}
@end
