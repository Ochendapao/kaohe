//
//  FirstPageViewController.m
//  CQUPT_CDP
//
//  Created by 陈大炮 on 2018/5/27.
//  Copyright © 2018年 陈大炮. All rights reserved.
//

#import "FirstPageViewController.h"
#import "FirstPageTableViewCell.h"
#import "FirstPageModel.h"
#define Screen_width [UIScreen mainScreen].bounds.size.width/375
@interface FirstPageViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (retain, nonatomic) UITableView *tableView;
@property (strong, nonatomic) NSMutableArray *arrayData;
@property (strong, nonatomic) UIButton *editButton;
@end

@implementation FirstPageViewController
- (void)createEditButton{
    _editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_editButton setImage:[UIImage imageNamed:@"求助按钮"] forState:UIControlStateNormal];
//    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
//    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    [_editButton addTarget:self action:@selector(clickEditButton) forControlEvents:UIControlEventTouchUpInside];
    _editButton.frame = CGRectMake(Screen_width*292, Screen_width*545, Screen_width*58, Screen_width*58);
    [self.view addSubview:_editButton];
    [self.view bringSubviewToFront:_editButton];
}
- (void)clickEditButton{
    
}
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, Screen_width*375, Screen_width*641) style:UITableViewStylePlain];
        _tableView.backgroundColor = [UIColor colorWithRed:241/255.0 green:241/255.0 blue:241/255.0 alpha:1];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    UINib *nib = [UINib nibWithNibName:@"FirstPageTableViewCell" bundle:nil];
    [_tableView registerNib:nib forCellReuseIdentifier:@"CellOne"];
    [self getInformation];
    return _tableView;
}

-(void)getInformation
{
    NSURL *url = [NSURL URLWithString :@"https://wx.idsbllp.cn/springtest/cyxbsMobile/index.php/QA/Question/getQuestionList"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setTimeoutInterval:10.0];
    [request setHTTPMethod:@"POST"];
    [request addValue:@"data" forHTTPHeaderField:@"application/x-www-form-urlencoded"];
    NSDictionary *parametersDict = @{@"page":@"0",@"size":@"6",@"kind":@"其他"};
    NSMutableString *parameterString = [NSMutableString string];
    int pos = 0;
    for (NSString *key  in parametersDict.allKeys) {
        [parameterString appendFormat:@"%@=%@",key,parametersDict[key]];
        if (pos<parametersDict.allKeys.count-1) {
            [parameterString appendString:@"&"];
            
        }
        pos++;
    }
    NSData *parametersData = [parameterString dataUsingEncoding:NSUTF8StringEncoding];
    [request setHTTPBody:parametersData];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"post error:%@",error.localizedDescription);
        }else{
            id object = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
            if (error) {
                NSLog(@"post error:%@",error.localizedDescription);
                UILabel* failLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
                failLabel.text=@"哎呀，网坏了!";
                failLabel.textColor=[UIColor blackColor];
                failLabel.backgroundColor=[UIColor colorWithRed:242/255.0 green:242/255.0 blue:242/255.0 alpha:1];
                failLabel.textAlignment=NSTextAlignmentCenter;
                
                [self.view addSubview:failLabel];
                [self->_tableView removeFromSuperview];
            }else{
                NSLog(@"poet success:%@",object);
                NSLog(@"%@",_arrayData);
                dispatch_async(dispatch_get_main_queue(), ^{
                   
                    NSDictionary *dicResult = [object objectForKey:@"data"];
                    for (NSDictionary *data in dicResult) {
                        FirstPageModel *model = [[FirstPageModel alloc]initWithDict:data];
                        [_arrayData addObject:model];
                        [_tableView reloadData];
                    }
                    //                    NSLog(@"%@",_arrayData);
                }
                               );
            }
        }
    }];
    
    [task resume];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _arrayData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *strId = @"CellOne";
    FirstPageTableViewCell *cell = [_tableView dequeueReusableCellWithIdentifier:strId];
    if (cell == nil) {
        cell = (FirstPageTableViewCell *)[[[NSBundle mainBundle]loadNibNamed:@"FirstPageTableViewCell" owner:self options:nil]firstObject];
        
    }
    cell.layer.cornerRadius = 6;
    cell.layer.masksToBounds = YES;
    cell.layer.shouldRasterize = YES;
    FirstPageModel *model = [_arrayData objectAtIndex:indexPath.section];
    cell.titleLabel.text = model.title;
    cell.iconImg.hidden = YES;
    cell.timeLineLabel.text = model.timeLine;
    cell.timeLineLabel.font = [UIFont systemFontOfSize:11];
    cell.timeLineLabel.textColor = [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1];
    cell.tagButton.titleLabel.text = model.tagLabel;
    cell.contentLabel.text = model.textViewContent;
    cell.contentLabel.font = [UIFont systemFontOfSize:14];
//    cell.rewardLabel.text  = model.reward;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 140;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:241/255.0 green:241/255.0 blue:241/255.0 alpha:0.5];
    // Do any additional setup after loading the view.
//    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"顶栏"] forBarMetrics:UIBarMetricsDefault];
//    self.navigationController.navigationBar.translucent = NO;
    _arrayData = [NSMutableArray array];
    [self.view addSubview:self.tableView];
    [self getInformation];
    [self createEditButton];
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 12;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 345, 12)];
    headerView.backgroundColor = [UIColor colorWithRed:241/255.0 green:241/255.0 blue:241/255.0 alpha:0.6];
    return headerView;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
