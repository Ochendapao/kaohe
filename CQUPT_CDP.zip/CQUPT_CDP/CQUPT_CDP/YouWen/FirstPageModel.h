//
//  FirstPageModel.h
//  CQUPT_CDP
//
//  Created by 陈大炮 on 2018/5/27.
//  Copyright © 2018年 陈大炮. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FirstPageModel : NSObject
@property (strong, nonatomic)NSString *title;
@property (strong, nonatomic)NSString *timeLine;
@property (strong, nonatomic)NSString *tagLabel;
@property (strong, nonatomic)NSString *textViewContent;
@property (strong, nonatomic)NSString *reward;

- (instancetype)initWithDict:(NSDictionary *)dic;
@end
