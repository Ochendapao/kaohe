//
//  YouWenViewController.m
//  CQUPT_CDP
//
//  Created by 陈大炮 on 2018/5/24.
//  Copyright © 2018年 陈大炮. All rights reserved.
//

#import "YouWenViewController.h"
#import "YouWenKindsViewController.h"

#import "YWTableAllViewController.h"
#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define kScreenHeight ([UIScreen mainScreen].bounds.size.height)
#define kNumber (self.segmentedControl.numberOfSegments)

@interface YouWenViewController ()


@property (nonatomic, strong) UIScrollView *TagScroll;
@property (nonatomic, strong) NSArray *channelArray;


@end

@implementation YouWenViewController
//-(UIScrollView *)TagScroll{
//
//    if (!_TagScroll) {
//        _TagScroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 64, 375, 41)];
//        NSArray *TagName = @[@"全部",@"情感",@"生活",@"其他"];
//        for (int i = 0; i<TagName.count; i++) {
//            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//            btn.frame = CGRectMake(0, 64, <#CGFloat width#>, <#CGFloat height#>)
//        }
//    }
//    return self;
//}
- (void)viewDidLoad {
    [super viewDidLoad];
//    self.automaticallyAdjustsScrollViewInsets = NO;
//    YWTableAllViewController *YWFirstvc = [[YWTableAllViewController alloc]init];
//    [self presentViewController:YWFirstvc animated:YES completion:nil];
//    segment = [[JXSegment alloc]initWithFrame:CGRectMake(0, 60, kScreenWidth, 40)];
//    [segment updateChannels:self.channelArray];
//
//    segment.delegate = self;
//    [self.view addSubview:segment];
//
//    pageView =[[JXPageView alloc]initWithFrame:CGRectMake(0, 100, kScreenWidth, self.view.bounds.size.height-100)];
//    pageView.datasource = self;
//    pageView.delegate = self;
//    [pageView reloadData];
//    [pageView changeToItemAtIndex:0];
//    [self.view addSubview:pageView];
 
}
//- (NSArray *)channelArray{
//    if (_channelArray == nil) {
//        _channelArray = @[@"全部",@"学习",@"生活",@"情感",@"其他"];
//    }
//    return _channelArray;
//}
//- (NSInteger)numberOfItemInJXPageView:(JXPageView *)pageView{
//    return self.channelArray.count;
//}
//- (UIViewController *)controller:(UIViewController *)CDPcontroller controllerAtIndex:(NSInteger)index{
//    YWTableAllViewController *controllers = [[YWTableAllViewController alloc]init];
//    controllers.view.backgroundColor = [UIColor blueColor];
//    return controllers;
//}
//- (UIView *)pageView:(JXPageView *)pageView viewAtIndex:(NSInteger)index{
//    UIView *view = [[UIView alloc]init];
//    YWTableAllViewController *controllers = [[YWTableAllViewController alloc]init];
//    controllers.view.backgroundColor = [UIColor blueColor];
//
//    [self addChildViewController:controllers];
//
//    return view;
//}

//- (void)JXSegment:(JXSegment *)segment didSelectIndex:(NSInteger)index{
//    [pageView changeToItemAtIndex:index];
//}
//
//- (void)didScrollToIndex:(NSInteger)index{
//    [segment didChengeToIndex:index];
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
