//
//  FirstPageTableViewCell.m
//  CQUPT_CDP
//
//  Created by 陈大炮 on 2018/5/27.
//  Copyright © 2018年 陈大炮. All rights reserved.
//

#import "FirstPageTableViewCell.h"
#define Screen_width [UIScreen mainScreen].bounds.size.width/375
@implementation FirstPageTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initializatin code
}
- (void)setFrame:(CGRect)frame{
    frame.origin.x =Screen_width*15;
    frame.size.width -= 2*Screen_width*15;
    [super setFrame:frame];
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.layer.cornerRadius = 6;
        self.layer.masksToBounds = YES;
        self.layer.shouldRasterize= YES;
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
