//
//  AppDelegate.m
//  CQUPT_CDP
//
//  Created by 陈大炮 on 2018/5/24.
//  Copyright © 2018年 陈大炮. All rights reserved.
//

#import "AppDelegate.h"
#import "YouWenViewController.h"
//#include "YWTableAllViewController.h"
#import "FirstPageViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //课表
    UIViewController *ClassVC = [[UIViewController alloc]init];
    ClassVC.title = @"课表";
    UINavigationController *navClass = [[UINavigationController alloc]initWithRootViewController:ClassVC];
    
    
    //    navClass.navigationBar.shadowImage = [UIImage imageNamed:@"状态栏@2x"];
    UITabBarItem *itemClass = [[UITabBarItem alloc]initWithTitle:ClassVC.title image:[UIImage imageNamed:@"课表图标"] selectedImage:[UIImage imageNamed:@"课表图标"]];
    ClassVC.tabBarItem = itemClass;
    
    
    //邮问
   FirstPageViewController *comVC = [[FirstPageViewController alloc]init];
    comVC.title = @"邮问";
    
    UINavigationController *comNav = [[UINavigationController alloc]initWithRootViewController:comVC];
    
    UITabBarItem *itemCom = [[UITabBarItem alloc]initWithTitle:comVC.title image:[UIImage imageNamed:@"邮问图标"] selectedImage:[UIImage imageNamed:@"邮问图标"]];
    comVC.tabBarItem = itemCom;
    comNav.navigationBar.backIndicatorImage = [UIImage imageNamed:@"顶栏"];

    
    
    
    //发现
    UIViewController *discoverVC = [[UIViewController alloc]init];
    discoverVC.title = @"发现";
    UINavigationController *discoverNav = [[UINavigationController alloc]initWithRootViewController:discoverVC];
    UITabBarItem *item = [[UITabBarItem alloc]initWithTitle:@"发现" image:[UIImage imageNamed:@"发现图标"] tag:0];
    discoverVC.tabBarItem = item
    ;
    
    
    
    
    //我的
    UIViewController *mineVC = [[UIViewController alloc]init];
    mineVC.title = @"我的";
    UINavigationController *mineNav = [[UINavigationController alloc]initWithRootViewController:mineVC];
    UITabBarItem *itemMine = [[UITabBarItem alloc]initWithTitle:mineVC.title image:[UIImage imageNamed:@"我的图标"] selectedImage:[UIImage imageNamed:@"我的图标"]];
    mineVC.tabBarItem = itemMine;
    
    
    //创建UITabBarController
    UITabBarController *tabBarVC = [[UITabBarController alloc]init];
    tabBarVC.viewControllers = @[navClass,comNav,discoverNav,mineNav];
    tabBarVC.selectedViewController = navClass;
    
    
    //定制tabbar的外观
//
//    tabBarVC.tabBar.tintColor = [UIColor colorWithRed:31/255.0 green:185/255.0 blue:35/255.0 alpha:1.0];
    tabBarVC.tabBar.backgroundImage = [UIImage imageNamed:@"底板"];
    
    
    
    
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = tabBarVC;
    [self.window makeKeyAndVisible];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
